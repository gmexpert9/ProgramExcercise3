/*
 * This program is to randomly generate a number from 1 to 10,000
 * and this program asks the user to put in their input 3 different times
 */

/**
 *
 * @author Christopher J Linney
 */
import static java.lang.Math.random;
import java.util.Random; //random number class
import java.util.Scanner; //scanner class


public class ProgrammingExcercise3 {

    public static void main(String[] args) {

System.out.println("Enter a number: "); // program asks the user to enter a #.

class number //number calss 
{
int t = 1; //general counter 
       
Random rand = new Random(); //random number


int  a = rand.nextInt(10000) + 1; //random number from 1 to 10k 

int n = 0; // numebr is default to 0    // numebr is default to 0    
 
/*do*/ 
{
    guess = keyboard.nextInt(); 

    if (guess > random) 
    {
        System.out.print("Lower!"); // message Lower!
        attempts += 1; 
    } 
    else 
    {
        System.out.print("Higher!"); // message Higher!
        attempts +=1;
    }
 while (guess != random);   
 
 scanner.close();
